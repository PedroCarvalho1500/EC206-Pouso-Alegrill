package controller;

public class InputListenerCadastro {

	public InputListenerCadastro() {
		// TODO Auto-generated constructor stub
	}

}
