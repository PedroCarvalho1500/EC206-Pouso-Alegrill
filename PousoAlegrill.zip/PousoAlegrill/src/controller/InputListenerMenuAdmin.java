package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.EditarBebida;
import view.EditarComida;
import view.EditarPedidos;
import view.EditarUsuario;
import view.Financeiro;
import view.Login;
import view.MenuAdmin;

public class InputListenerMenuAdmin implements ActionListener{

	private MenuAdmin tela;
	
	public InputListenerMenuAdmin (MenuAdmin tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {		
		if (event.getActionCommand() == "MESAS") {
			mesas();
		}
		else if (event.getActionCommand() == "COZINHA") {
			cozinha();
		}
		else if (event.getActionCommand() == "BAR") {
			bar();
		}
		else if (event.getActionCommand() == "PEDIDOS") {
			pedidos();
		}
		else if (event.getActionCommand() == "COMIDAS") {
			comidas();
		}
		else if (event.getActionCommand() == "BEBIDAS") {
			bebidas();
		}
		else if (event.getActionCommand() == "USUARIOS") {
			usuarios();
		}
		else if (event.getActionCommand() == "FINANCEIRO") {
			financeiro();
		}
		else if (event.getActionCommand() == "LOGOUT") {
			logout();
		}

	}
	
	private void mesas() {
		tela.setBtnMesas(false);
		tela.setBtnCozinha(true);
		tela.setBtnBar(true);
		tela.setList(tela.getMesas());
	}

	private void cozinha() {
		tela.setBtnMesas(true);
		tela.setBtnCozinha(false);
		tela.setBtnBar(true);
		tela.setList(tela.getCozinha());
	}

	private void bar() {
		tela.setBtnMesas(true);
		tela.setBtnCozinha(true);
		tela.setBtnBar(false);
		tela.setList(tela.getBar());
	}

	private void pedidos() {
		try {
			tela.dispose();
			new EditarPedidos().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	private void comidas() {
		try {
			tela.dispose();
			new EditarComida().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void bebidas() {
		try {
			tela.dispose();
			new EditarBebida().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}

	private void usuarios() {
		try {
			tela.dispose();
			new EditarUsuario().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	private void financeiro() {
		try {
			tela.dispose();
			new Financeiro().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	private void logout() {
		try {
			//Setar o usuario atual para null
			tela.dispose();
			new Login().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
