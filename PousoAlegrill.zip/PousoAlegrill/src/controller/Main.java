package controller;

import java.util.ArrayList;

import model.Usuario;
import view.Login;

public class Main {	
	public static void main(String[] args) {
		new Login().setVisible(true);
	}

}
