package model;

public class Bebida {

	private int id;
	private String nome;
	private String descricao;
	private int categoria; //1 - alcoolica, 2 - nao alcoolica
	private Boolean disponivel; //true - disponivel, false - indisponivel
	private float preco;
	private float quantidade; //volume da porcao
	private int unidade; //1 - ml, 2 - l, etc
	
	public Bebida(int id, String nome, String descricao, int categoria, Boolean disponivel, float preco,
			float quantidade, int unidade) {
		super();
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.categoria = categoria;
		this.disponivel = disponivel;
		this.preco = preco;
		this.quantidade = quantidade;
		this.unidade = unidade;
	}

	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getCategoria() {
		return categoria;
	}

	public Boolean getDisponivel() {
		return disponivel;
	}

	public float getPreco() {
		return preco;
	}

	public float getQuantidade() {
		return quantidade;
	}

	public int getUnidade() {
		return unidade;
	}
	
	
	

}
