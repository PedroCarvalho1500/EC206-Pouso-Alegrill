package model;

public class ComidaDAO {

}
