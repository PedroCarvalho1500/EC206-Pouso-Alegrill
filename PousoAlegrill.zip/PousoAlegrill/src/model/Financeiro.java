package model;

import java.util.Date;

public class Financeiro {
	private int id;
	private Date data;
	private int mesa;
	
	public Financeiro(int id, Date data, int mesa) {
		super();
		this.id = id;
		this.data = data;
		this.mesa = mesa;
	}

	public int getId() {
		return id;
	}

	public Date getData() {
		return data;
	}

	public int getMesa() {
		return mesa;
	}

	
}
