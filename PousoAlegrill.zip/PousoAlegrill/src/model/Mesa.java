package model;

import java.util.ArrayList;

public class Mesa {

	private int id;
	private int numero;
	private float conta;
	private ArrayList<Comida> comidas;
	private ArrayList<Bebida> bebidas;

	public Mesa(int id, int numero, float conta, ArrayList<Comida> comidas, ArrayList<Bebida> bebidas) {
		super();
		this.id = id;
		this.numero = numero;
		this.conta = conta;
		this.comidas = comidas;
		this.bebidas = bebidas;
	}

	public int getId() {
		return id;
	}

	public int getNumero() {
		return numero;
	}

	public float getConta() {
		return conta;
	}

	public ArrayList<Comida> getComidas() {
		return comidas;
	}

	public ArrayList<Bebida> getBebidas() {
		return bebidas;
	}
	
	
}
