package model;

public class MesaDAO {

}
