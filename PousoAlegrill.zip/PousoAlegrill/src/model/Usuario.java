package model;

public class Usuario {

	private int id;
	private String nome;
	private String email;
	private String senha;
	private int funcao; //0 - n�o assignado, 1 - admin, 2 - atendimento, 3 - cozinha, 4 - bar

	public Usuario(int id, String nome, String email, String senha) {
		super();
		this.id = id;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.funcao = 0;
	}

	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getEmail() {
		return email;
	}

	public String getSenha() {
		return senha;
	}

	public int getFuncao() {
		return funcao;
	}

	public void setFuncao(int funcao) {
		this.funcao = funcao;
	}

	
}
