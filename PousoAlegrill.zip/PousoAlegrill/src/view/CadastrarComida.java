package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class CadastrarComida extends JFrame {

	private JPanel contentPane;
	private JTextField textNome;
	private JTextField textField_1;
	private JTextField textPreco;
	private JTextField textQuant;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastrarComida frame = new CadastrarComida();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastrarComida() {
		setTitle("CADASTRAR COMIDA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textNome = new JTextField();
		textNome.setBounds(108, 28, 86, 20);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(108, 69, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(20, 31, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblDescricao = new JLabel("Descri\u00E7\u00E3o: ");
		lblDescricao.setBounds(20, 72, 68, 14);
		contentPane.add(lblDescricao);
		
		JComboBox comboBox_Categoria = new JComboBox();
		comboBox_Categoria.setBounds(108, 102, 86, 20);
		contentPane.add(comboBox_Categoria);
		
		JLabel lblCategoria = new JLabel("Categoria: ");
		lblCategoria.setBounds(20, 105, 68, 14);
		contentPane.add(lblCategoria);
		
		JLabel lblPreco = new JLabel("Pre\u00E7o: ");
		lblPreco.setBounds(20, 143, 46, 14);
		contentPane.add(lblPreco);
		
		textPreco = new JTextField();
		textPreco.setBounds(108, 140, 86, 20);
		contentPane.add(textPreco);
		textPreco.setColumns(10);
		
		JLabel lblQuant = new JLabel("Quantidade: ");
		lblQuant.setBounds(20, 168, 46, 14);
		contentPane.add(lblQuant);
		
		textQuant = new JTextField();
		textQuant.setBounds(108, 171, 86, 20);
		contentPane.add(textQuant);
		textQuant.setColumns(10);
		
		JComboBox comboBox_Unidade = new JComboBox();
		comboBox_Unidade.setBounds(108, 202, 86, 20);
		contentPane.add(comboBox_Unidade);
		
		JLabel lblUnidade = new JLabel("Unidade: ");
		lblUnidade.setBounds(20, 210, 46, 14);
		contentPane.add(lblUnidade);
		
		JButton btnCadastrar = new JButton("Cadastrar");
		btnCadastrar.setBounds(230, 227, 89, 23);
		contentPane.add(btnCadastrar);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(335, 227, 89, 23);
		contentPane.add(btnVoltar);
	}
}
