package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Cadastro extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8078668418163319487L;
	private JPanel contentPane;
	private JTextField textNome;
	private JTextField textEmail;
	private JTextField textSenha;
	private JTextField textConfSenha;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cadastro frame = new Cadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cadastro() {
		setTitle("CADASTRO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textNome = new JTextField();
		textNome.setBounds(140, 33, 170, 20);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		textEmail = new JTextField();
		textEmail.setBounds(140, 65, 170, 20);
		contentPane.add(textEmail);
		textEmail.setColumns(10);
		
		textSenha = new JTextField();
		textSenha.setBounds(140, 96, 170, 20);
		contentPane.add(textSenha);
		textSenha.setColumns(10);
		
		textConfSenha = new JTextField();
		textConfSenha.setBounds(140, 127, 170, 20);
		contentPane.add(textConfSenha);
		textConfSenha.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(43, 36, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(43, 68, 46, 14);
		contentPane.add(lblEmail);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setBounds(43, 99, 46, 14);
		contentPane.add(lblSenha);
		
		JLabel lblConfSenha = new JLabel("Confirma Senha:");
		lblConfSenha.setBounds(43, 130, 86, 14);
		contentPane.add(lblConfSenha);
		
		JButton btnCadastro = new JButton("Cadastrar");
		btnCadastro.setBounds(215, 201, 89, 23);
		contentPane.add(btnCadastro);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(80, 201, 89, 23);
		contentPane.add(btnVoltar);
	}
}
