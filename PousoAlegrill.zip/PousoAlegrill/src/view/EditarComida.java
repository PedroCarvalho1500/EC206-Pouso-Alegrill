package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class EditarComida extends JFrame {

	private JPanel contentPane;
	private JTextField textNome;
	private JTextField textDescricao;
	private JTextField textPreco;
	private JTextField textQuantidade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarComida frame = new EditarComida();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarComida() {
		setTitle("EDITAR COMIDA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList listComida = new JList();
		listComida.setBounds(98, 29, -65, 50);
		contentPane.add(listComida);
		
		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(153, 34, 46, 14);
		contentPane.add(lblNome);
		
		textNome = new JTextField();
		textNome.setBounds(250, 31, 86, 20);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		JLabel lblDescricao = new JLabel("Descri\u00E7\u00E3o: ");
		lblDescricao.setBounds(153, 65, 46, 14);
		contentPane.add(lblDescricao);
		
		textDescricao = new JTextField();
		textDescricao.setBounds(250, 62, 86, 20);
		contentPane.add(textDescricao);
		textDescricao.setColumns(10);
		
		JLabel lblCategoria = new JLabel("Categoria: ");
		lblCategoria.setBounds(153, 105, 46, 14);
		contentPane.add(lblCategoria);
		
		JLabel lblPreco = new JLabel("Pre\u00E7o: ");
		lblPreco.setBounds(153, 141, 46, 14);
		contentPane.add(lblPreco);
		
		JComboBox comboBox_Categoria = new JComboBox();
		comboBox_Categoria.setBounds(250, 105, 86, 20);
		contentPane.add(comboBox_Categoria);
		
		textPreco = new JTextField();
		textPreco.setBounds(250, 138, 86, 20);
		contentPane.add(textPreco);
		textPreco.setColumns(10);
		
		JLabel lblQuantidade = new JLabel("Quantidade: ");
		lblQuantidade.setBounds(153, 180, 46, 14);
		contentPane.add(lblQuantidade);
		
		textQuantidade = new JTextField();
		textQuantidade.setBounds(250, 177, 86, 20);
		contentPane.add(textQuantidade);
		textQuantidade.setColumns(10);
		
		JLabel lblUnidade = new JLabel("Unidade: ");
		lblUnidade.setBounds(153, 213, 46, 14);
		contentPane.add(lblUnidade);
		
		JComboBox comboBox_Unidade = new JComboBox();
		comboBox_Unidade.setBounds(250, 208, 82, 20);
		contentPane.add(comboBox_Unidade);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.setBounds(247, 239, 89, 23);
		contentPane.add(btnEditar);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(10, 239, 89, 23);
		contentPane.add(btnVoltar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(128, 239, 89, 23);
		contentPane.add(btnExcluir);
	}
}
