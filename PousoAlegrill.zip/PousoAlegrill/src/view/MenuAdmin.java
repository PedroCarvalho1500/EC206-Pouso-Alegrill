package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

public class MenuAdmin extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuAdmin frame = new MenuAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuAdmin() {
		setTitle("MENU ADMINISTRADOR");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnEditarComida = new JButton("Editar Comida");
		btnEditarComida.setBounds(10, 61, 120, 30);
		contentPane.add(btnEditarComida);
		
		JButton btnCadastrarComida = new JButton("Cadastrar Comida");
		btnCadastrarComida.setBounds(10, 11, 120, 30);
		contentPane.add(btnCadastrarComida);
		
		JButton btnListarComida = new JButton("Listar Comida");
		btnListarComida.setBounds(10, 95, 120, 30);
		contentPane.add(btnListarComida);
		
		JButton btnExcluirComida = new JButton("Excluir Comida");
		btnExcluirComida.setBounds(10, 140, 120, 30);
		contentPane.add(btnExcluirComida);
		
		JButton btnEditarUsuario = new JButton("Editar Usuario");
		btnEditarUsuario.setBounds(10, 193, 120, 30);
		contentPane.add(btnEditarUsuario);
		
		JButton btnExcluirUsuario = new JButton("Excluir Usuario");
		btnExcluirUsuario.setBounds(300, 193, 89, 23);
		contentPane.add(btnExcluirUsuario);
		
		JButton btnListarUsuario = new JButton("Listar Usuario");
		btnListarUsuario.setBounds(177, 193, 120, 30);
		contentPane.add(btnListarUsuario);
		
		JButton btnCadastrarBebida = new JButton("Cadastrar Bebida");
		btnCadastrarBebida.setBounds(177, 17, 120, 30);
		contentPane.add(btnCadastrarBebida);
		
		JButton btnEditarBebida = new JButton("Editar Bebida");
		btnEditarBebida.setBounds(177, 61, 120, 30);
		contentPane.add(btnEditarBebida);
		
		JButton btnListarBebida = new JButton("Listar Bebida");
		btnListarBebida.setBounds(177, 95, 120, 30);
		contentPane.add(btnListarBebida);
		
		JButton btnExcluirBebida = new JButton("Excluir Bebida");
		btnExcluirBebida.setBounds(177, 140, 120, 30);
		contentPane.add(btnExcluirBebida);
		
		JButton btnCadastrarMesa = new JButton("Cadastrar Mesa");
		btnCadastrarMesa.setBounds(300, 17, 120, 30);
		contentPane.add(btnCadastrarMesa);
		
		JButton btnEditarMesa = new JButton("Editar Mesa");
		btnEditarMesa.setBounds(300, 61, 120, 30);
		contentPane.add(btnEditarMesa);
		
		JButton btnListarMesa = new JButton("Listar Mesa");
		btnListarMesa.setBounds(300, 95, 120, 30);
		contentPane.add(btnListarMesa);
		
		JButton btnExcluirMesa = new JButton("Excluir Mesa");
		btnExcluirMesa.setBounds(300, 140, 89, 23);
		contentPane.add(btnExcluirMesa);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(300, 227, 89, 23);
		contentPane.add(btnVoltar);
	}

}
