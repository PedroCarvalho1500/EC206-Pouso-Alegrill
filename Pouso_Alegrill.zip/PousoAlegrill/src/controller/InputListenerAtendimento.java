package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Atendimento;
import view.Login;

public class InputListenerAtendimento implements ActionListener {

	private Atendimento tela;
	
	public InputListenerAtendimento(Atendimento tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "LOGOUT") {
			logout();
		}

	}
	
	private void logout() {
		try {
			//Setar o usuario atual para null
			tela.dispose();
			new Login().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
