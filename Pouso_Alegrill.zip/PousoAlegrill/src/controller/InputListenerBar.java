package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Bar;
import view.Login;

public class InputListenerBar implements ActionListener {

	private Bar tela;
	
	public InputListenerBar (Bar tela) {
		this.tela = tela;
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "LOGOUT") {
			logout();
		}

	}
	
	private void logout() {
		try {
			//Setar o usuario atual para null
			tela.dispose();
			new Login().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
