package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.EditarBebida;
import view.Login;
import view.MenuAdmin;

public class InputListenerEditarBebida implements ActionListener {

	private EditarBebida tela;
	
	public InputListenerEditarBebida (EditarBebida tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "VOLTAR") {
			voltar();
		}

	}
	
	private void voltar() {
		try {
			tela.dispose();
			new MenuAdmin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
