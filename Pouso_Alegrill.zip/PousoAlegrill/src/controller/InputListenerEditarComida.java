package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.EditarComida;
import view.MenuAdmin;

public class InputListenerEditarComida implements ActionListener {

	private EditarComida tela;
	
	public InputListenerEditarComida (EditarComida tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "VOLTAR") {
			voltar();
		}

	}
	
	private void voltar() {
		try {
			tela.dispose();
			new MenuAdmin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
