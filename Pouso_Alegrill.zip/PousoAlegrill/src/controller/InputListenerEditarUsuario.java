package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.EditarUsuario;
import view.MenuAdmin;

public class InputListenerEditarUsuario implements ActionListener {

	private EditarUsuario tela;
	
	public InputListenerEditarUsuario (EditarUsuario tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "VOLTAR") {
			voltar();
		}

	}
	
	private void voltar() {
		try {
			tela.dispose();
			new MenuAdmin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
