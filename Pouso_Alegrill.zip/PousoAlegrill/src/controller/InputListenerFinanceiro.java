package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.Financeiro;
import view.MenuAdmin;

public class InputListenerFinanceiro implements ActionListener {

	private Financeiro tela;
	
	public InputListenerFinanceiro (Financeiro tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getActionCommand() == "VOLTAR") {
			voltar();
		}

	}
	
	private void voltar() {
		try {
			tela.dispose();
			new MenuAdmin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
