package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.SelectedUsuario;
import model.Usuario;
import model.UsuarioDAO;
import view.CadastroFrame;
import view.Login;
import view.Menu;

public class InputListenerLogin implements ActionListener{

	private Login tela;
	private UsuarioDAO UsuarioDAO = new UsuarioDAO();
	
	public InputListenerLogin(Login tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {

		if(event.getActionCommand() == "CADASTRAR") {
			cadastrar();
		}
		else if(event.getActionCommand() == "LOGIN") {
			login();
		}
		
	}

	private void login() {
		try {
		
			String email = tela.getEmail();
			String senha = tela.getSenha();
			
			if(email.equals("") || senha.equals("") || !email.contains("@")) {
				String message = "Informacoes incorretas";
				JOptionPane.showMessageDialog(tela, message, "Warning", JOptionPane.WARNING_MESSAGE);
			}
			else {
				
					ArrayList<Usuario> usuarios;
					
					UsuarioDAO.conectar();
					usuarios = UsuarioDAO.downloadUsuarios();
					UsuarioDAO.desconectar();
					
					@SuppressWarnings("unused")
					SelectedUsuario selectedUsuario = null;
					boolean isMatch = false;
					
					for(Usuario usuario : usuarios) {
						if(usuario.getEmail().equals(email)) {
							if(usuario.getSenha().equals(senha)) {
								selectedUsuario = SelectedUsuario.setUsuario(usuario);
								isMatch = true;
								break;
							}
						}
					}
					
					if(isMatch) {
						tela.dispose();
						new Menu().setVisible(true);
					}
					else {
						String message = "Email ou senha incorretos!";
						JOptionPane.showMessageDialog(tela, message, "Erro", JOptionPane.ERROR_MESSAGE);
					}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

	private void cadastrar() {
		try {
			tela.dispose();
			new CadastroFrame().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
