package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import model.Usuario;
import model.UsuarioDAO;
import view.Atendimento;
import view.Bar;
import view.Cadastro;
import view.Cozinha;
import view.Login;
import view.MenuAdmin;

public class InputListenerLogin implements ActionListener{

	private Login tela;
	private UsuarioDAO UsuarioDAO = new UsuarioDAO();
	
	public InputListenerLogin(Login tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {

		if(event.getActionCommand() == "CADASTRAR") {
			cadastrar();
		}
		else if(event.getActionCommand() == "LOGIN") {
			login();
		}
		
	}

	private void login() {
		try {
		
			String email = tela.getEmail();
			String senha = tela.getSenha();
			
			if(email.equals("") || senha.equals("") || !email.contains("@")) {
				String message = "Informacoes incorretas";
				JOptionPane.showMessageDialog(tela, message, "Warning", JOptionPane.WARNING_MESSAGE);
			}
			else {
				
					ArrayList<Usuario> usuarios;
					/*
					UsuarioDAO.conectar();
					usuarios = UsuarioDAO.downloadUsuarios();
					UsuarioDAO.desconectar();
					*/
					@SuppressWarnings("unused")
					Usuario selectedUsuario = null;
					boolean isMatch = false;
					
					for(Usuario usuario : usuarios) {
						if(usuario.getEmail().equals(email)) {
							if(usuario.getSenha().equals(senha)) {
								selectedUsuario = new Usuario(usuario);
								isMatch = true;
								break;
							}
						}
					}
					
					if(isMatch) {
						tela.dispose();
						switch (selectedUsuario.getFuncao()) {
						case 1:
							new Atendimento().setVisible(true);
							break;
						case 2:
							new Cozinha().setVisible(true);
							break;
						case 3:
							new Bar().setVisible(true);
							break;
						case 4:
							new MenuAdmin().setVisible(true);
							break;
						default:
							new Login().setVisible(true);
							String message = "Voce nao exerce nenhuma funcao. Comunique ao administrador do sistema.";
							JOptionPane.showMessageDialog(tela, message, "Warning", JOptionPane.WARNING_MESSAGE);							
							break;
						}
					}
					else {
						String message = "Email ou senha incorretos!";
						JOptionPane.showMessageDialog(tela, message, "Erro", JOptionPane.ERROR_MESSAGE);
					}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

	private void cadastrar() {
		try {
			tela.dispose();
			new Cadastro().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
