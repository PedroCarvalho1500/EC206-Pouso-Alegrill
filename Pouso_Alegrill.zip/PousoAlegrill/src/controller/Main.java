package controller;

import model.Usuario;
import view.TelaLogin;

public class Main {	
	public static void main(String[] args) {
		new TelaLogin().setVisible(true);
	}

}
