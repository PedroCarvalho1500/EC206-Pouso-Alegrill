package model;

public class Bebida {
	private int id;
	private String nome;
	private String descricao;
	private int categoria; //1 - alcoolica, 2 - nao alcoolica
	private Boolean disponivel; //true - disponivel, false - indisponivel
	private float preco;
	private float quantidade; //volume da porcao
	private int unidade; //1 - ml, 2 - l, etc
}
