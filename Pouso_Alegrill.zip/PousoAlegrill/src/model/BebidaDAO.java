package model;

public class BebidaDAO {

}
