package model;

import java.sql.SQLException;
import java.util.ArrayList;

public class BebidaDAO extends ConexaoDAO{
	public ArrayList<Bebida> downloadBebidas() throws SQLException{
		ArrayList<Bebida> bebida = new ArrayList<Bebida>();
		
		String sql;
		sql = "SELECT *FROM bebida";
		ps = connection.prepareStatement(sql);
		resultSet = ps.executeQuery();
		
		while(resultSet.next()){
			int id = resultSet.getInt("idBebida");
			String nome = resultSet.getString("nome");
			String descricao = resultSet.getString("descricao");
			int categoria = resultSet.getInt("categoria");
			Boolean disponivel = resultSet.getBoolean("disponivel");
			float preco = resultSet.getFloat("preco");
			float quantidade = resultSet.getFloat("quantidade");
			int unidade = resultSet.getInt("unidade");
			Boolean servida = resultSet.getBoolean("servida");
			int numeroMesa = resultSet.getInt("numeroMesa");
			int mesa_idMesa = resultSet.getInt("mesa_idMesa");

			bebida.add(new Bebida(id, nome, descricao, categoria, disponivel, preco, quantidade, unidade, servida, numeroMesa, mesa_idMesa));
		}
		return bebida;
	}
	
	public void insertBebida(Bebida bebida) throws SQLException{
		String sql = "INSERT INTO bebida (nome, descricao, categoria, disponivel, preco, quantidade, unidade, servida, numeroMesa, mesa_idMesa) VALUES (?,?,?,?,?,?,?,?,?,?)";
		ps = connection.prepareStatement(sql);
		ps.setString(1, bebida.getNome());
		ps.setString(2, bebida.getDescricao());
		ps.setInt(3, bebida.getCategoria());
		ps.setBoolean(4, bebida.getDisponivel());
		ps.setFloat(5, bebida.getPreco());
		ps.setFloat(6, bebida.getQuantidade());
		ps.setInt(7, bebida.getUnidade());
		ps.setBoolean(8, bebida.getServida());
		ps.setInt(9, bebida.getNumeroMesa());
		ps.setInt(10, bebida.getMesa_idMesa());
		ps.executeUpdate();
	}
	
	public void editBebida(Bebida bebida, int id) throws SQLException{
		String sql = "UPDATE bebida SET disponivel=?, preco=?, quantidade=?, unidade=?, servida=? WHERE idBebida=?";
		ps = connection.prepareStatement(sql);
		ps.setBoolean(1, bebida.getDisponivel());
		ps.setFloat(2, bebida.getPreco());
		ps.setFloat(3, bebida.getQuantidade());
		ps.setInt(4, bebida.getUnidade());
		ps.setBoolean(5, bebida.getServida());
		ps.setInt(6, id);
		ps.executeUpdate();
	}	
	
	public void excluirBebida(Bebida bebida) throws SQLException{
		String sql = "DELETE FROM bebida WHERE idBebida=?";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, bebida.getId());
		ps.executeUpdate();
	}
}
