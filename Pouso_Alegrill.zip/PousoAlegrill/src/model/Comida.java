package model;

public class Comida {

	private int id;
	private String nome;
	private String descricao;
	private int categoria; //1 - petisco, 2 - prato, 3 - sobremesa, etc
	private Boolean disponivel; //true - disponivel, false - indisponivel
	private float preco;
	private float quantidade; //peso da porcao
	private int unidade; //1 - Kg, 2 - Un
	private Boolean servida;
	private int numeroMesa;
	
	public Comida(int id, String nome, String descricao, int categoria, float preco,
			float quantidade, int unidade) {
		super();
		this.id = id;
		this.nome = nome;
		this.descricao = descricao;
		this.categoria = categoria;
		this.disponivel = true;
		this.preco = preco;
		this.quantidade = quantidade;
		this.unidade = unidade;
		this.servida = false;
		this.numeroMesa = -1;
	}

	public int getNumeroMesa() {
		return numeroMesa;
	}

	public void setNumeroMesa(int numeroMesa) {
		this.numeroMesa = numeroMesa;
	}

	public int getId() {
		return id;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public int getCategoria() {
		return categoria;
	}

	public Boolean getDisponivel() {
		return disponivel;
	}

	public float getPreco() {
		return preco;
	}

	public float getQuantidade() {
		return quantidade;
	}

	public int getUnidade() {
		return unidade;
	}
	
	public Boolean getServida() {
		return servida;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public void setDisponivel(Boolean disponivel) {
		this.disponivel = disponivel;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	public void setQuantidade(float quantidade) {
		this.quantidade = quantidade;
	}

	public void setUnidade(int unidade) {
		this.unidade = unidade;
	}

	public void setServida(Boolean servida) {
		this.servida = servida;
	}
	
	

}
