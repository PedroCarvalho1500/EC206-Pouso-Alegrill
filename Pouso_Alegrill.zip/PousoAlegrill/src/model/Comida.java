package model;

public class Comida {
	private int id;
	private String nome;
	private String descricao;
	private int categoria; //1 - petisco, 2 - prato, 3 - sobremesa, etc
	private Boolean disponivel; //true - disponivel, false - indisponivel
	private float preco;
	private float quantidade; //peso da porcao
	private int unidade; //1 - Kg, 2 - Un
}
