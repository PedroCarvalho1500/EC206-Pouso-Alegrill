package model;

import java.sql.SQLException;
import java.util.ArrayList;

public class ComidaDAO extends ConexaoDAO{
	public ArrayList<Comida> downloadComidas() throws SQLException{
		ArrayList<Comida> comida = new ArrayList<Comida>();
		
		String sql;
		sql = "SELECT *FROM comida";
		ps = connection.prepareStatement(sql);
		resultSet = ps.executeQuery();
		
		while(resultSet.next()){
			int id = resultSet.getInt("idComida");
			String nome = resultSet.getString("nome");
			String descricao = resultSet.getString("descricao");
			int categoria = resultSet.getInt("categoria");
			Boolean disponivel = resultSet.getBoolean("disponivel");
			float preco = resultSet.getFloat("preco");
			float quantidade = resultSet.getFloat("quantidade");
			int unidade = resultSet.getInt("unidade");
			Boolean servida = resultSet.getBoolean("servida");
			int numeroMesa = resultSet.getInt("numeroMesa");
			int mesa_idMesa = resultSet.getInt("mesa_idMesa");

			comida.add(new Comida(id, nome, descricao, categoria, disponivel, preco, quantidade, unidade, servida, numeroMesa, mesa_idMesa));
		}
		return comida;
	}
	
	public void insertComida(Comida comida) throws SQLException{
		String sql = "INSERT INTO comida (nome, descricao, categoria, disponivel, preco, quantidade, unidade, servida, numeroMesa, mesa_idMesa) VALUES (?,?,?,?,?,?,?,?,?,?)";
		ps = connection.prepareStatement(sql);
		ps.setString(1, comida.getNome());
		ps.setString(2, comida.getDescricao());
		ps.setInt(3, comida.getCategoria());
		ps.setBoolean(4, comida.getDisponivel());
		ps.setFloat(5, comida.getPreco());
		ps.setFloat(6, comida.getQuantidade());
		ps.setInt(7, comida.getUnidade());
		ps.setBoolean(8, comida.getServida());
		ps.setInt(9, comida.getNumeroMesa());
		ps.setInt(10, comida.getMesa_idMesa());
		ps.executeUpdate();
	}
	
	public void editComida(Comida comida, int id) throws SQLException{
		String sql = "UPDATE comida SET disponivel=?, preco=?, quantidade=?, unidade=?, servida=? WHERE idComida=?";
		ps = connection.prepareStatement(sql);
		ps.setBoolean(1, comida.getDisponivel());
		ps.setFloat(2, comida.getPreco());
		ps.setFloat(3, comida.getQuantidade());
		ps.setInt(4, comida.getUnidade());
		ps.setBoolean(5, comida.getServida());
		ps.setInt(6, id);
		ps.executeUpdate();
	}	
	
	public void excluirComida(Comida comida) throws SQLException{
		String sql = "DELETE FROM comida WHERE idComida=?";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, comida.getId());
		ps.executeUpdate();
	}
}