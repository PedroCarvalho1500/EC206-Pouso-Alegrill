package model;

import java.util.Date;

public class Financeiro {
	private int id;
	private Date data;
	private Mesa mesa;
	
	public Financeiro(int id, Date data, Mesa mesa) {
		super();
		this.id = id;
		this.data = data;
		this.mesa = mesa;
	}

	public int getId() {
		return id;
	}

	public Date getData() {
		return data;
	}

	public Mesa getMesa() {
		return mesa;
	}

	
}
