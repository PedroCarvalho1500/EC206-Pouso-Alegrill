package model;

import java.util.Date;

public class Financeiro {
	private int id;
	private Date data;
	private Mesa mesa;
}
