package model;

public class FinanceiroDAO {

}
