package model;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.xml.crypto.Data;

public class FinanceiroDAO extends ConexaoDAO{
	public ArrayList<Financeiro> downloadFinancas() throws SQLException{
		ArrayList<Financeiro> financ = new ArrayList<Financeiro>();
		
		String sql;
		sql = "SELECT *FROM financeiro";
		ps = connection.prepareStatement(sql);
		resultSet = ps.executeQuery();
		
		while(resultSet.next()){
			int id = resultSet.getInt("idFinanceiro");
			Date data = resultSet.getDate("data");
			int mesa = resultSet.getInt("mesa");

			financ.add(new Financeiro(id, data, mesa));
		}
		return financ;
	}
	
	public void insertFinanceiro(Financeiro financeiro) throws SQLException{
		String sql = "INSERT INTO financeiro (data, mesa) VALUES (?,?)";
		ps = connection.prepareStatement(sql);
	//	ps.setDate(1, financeiro.getData());
		ps.setInt(2, financeiro.getMesa());
		ps.executeUpdate();
	}
	
	public void editFinanceiro(Financeiro financeiro, int id) throws SQLException{
		String sql = "UPDATE financeiro SET data=?, mesa=? WHERE idFinanceiro=?";
		ps = connection.prepareStatement(sql);
		//ps.setBoolean(1, financeiro.getData());
		ps.setInt(2, financeiro.getMesa());
		ps.setInt(3, id);
		ps.executeUpdate();
	}	
	
	public void excluirFinanceiro(Financeiro financeiro) throws SQLException{
		String sql = "DELETE FROM financeiro WHERE idFinanceiro=?";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, financeiro.getId());
		ps.executeUpdate();
	}
}