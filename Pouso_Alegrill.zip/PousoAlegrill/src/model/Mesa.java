package model;

import java.util.ArrayList;

public class Mesa {

	private int id;
	private int numero;
	private float conta;
	private boolean finalizada;
	private ArrayList<Comida> comidas;
	private ArrayList<Bebida> bebidas;

	public Mesa(int id, int numero) {
		super();
		this.id = id;
		this.numero = numero;
		this.conta = 0;
		this.comidas = null;
		this.bebidas = null;
		this.finalizada = false;
	}

	public int getId() {
		return id;
	}

	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}

	public float getConta() {
		this.conta = 0;
		if (this.comidas != null) {
			for (Comida comida : this.comidas) {
				this.conta += comida.getPreco();
			}
		}
		if (this.bebidas != null) {
			for (Bebida bebida : bebidas) {
				this.conta += bebida.getPreco();
			}
		}		
		return this.conta;
	}

	public ArrayList<Comida> getComidas() {
		return comidas;
	}
	
	public void addComida(Comida comida, int index) {
		this.comidas.add(index, comida);
	}

	public ArrayList<Bebida> getBebidas() {
		return bebidas;
	}
	
	public void addBebida(Bebida bebida) {
		this.bebidas.add(bebida);
	}

	public boolean isFinalizada() {
		return finalizada;
	}

	public void setFinalizada(boolean finalizada) {
		this.finalizada = finalizada;
	}	
}
