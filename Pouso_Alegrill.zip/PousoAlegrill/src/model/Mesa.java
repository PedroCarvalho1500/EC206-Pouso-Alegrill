package model;

import java.util.ArrayList;

public class Mesa {
	private int id;
	private int numero;
	private float conta;
	private ArrayList<Comida> comidas;
	private ArrayList<Bebida> bebidas;
}
