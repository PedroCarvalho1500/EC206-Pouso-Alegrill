package model;

import java.util.ArrayList;

public class Mesa {

	private int id;
	private int numero;
	private float conta;
	private boolean finalizada;
	private ArrayList<Comida> comidas;
	private ArrayList<Bebida> bebidas;

	public Mesa(int id, int numero, float conta, boolean finalizada) {
		super();
		this.id = id;
		this.numero = numero;
		if(conta <= 0) {
			this.conta = 0;
		}
		else {
			this.conta = conta;
		}
		this.comidas = new ArrayList<>();
		this.bebidas = new ArrayList<>();
		this.finalizada = finalizada;
	}
	
	public Mesa(int id, int numero, float conta, boolean finalizada, ArrayList<Comida> comidas, ArrayList<Bebida> bebidas) {
		super();
		this.id = id;
		this.numero = numero;
		if(conta <= 0) {
			this.conta = 0;
		}
		else {
			this.conta = conta;
		}
		this.comidas = comidas;
		this.bebidas = bebidas;
		this.finalizada = finalizada;
	}

	public int getId() {
		return id;
	}

	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}

	public float getConta() {		
		return this.conta;
	}
	
	public void setConta() {
		this.conta = 0;
		if (this.comidas != null) {
			for (Comida comida : this.comidas) {
				this.conta += comida.getPreco();
			}
		}
		if (this.bebidas != null) {
			for (Bebida bebida : this.bebidas) {
				this.conta += bebida.getPreco();
			}
		}
	}

	public ArrayList<Comida> getComidas() {
		return this.comidas;
	}
	
	public void addComida(Comida comida) {
		this.comidas.add(comida);
	}
	
	public void removeComida(Comida comida) {
		this.comidas.remove(comida);
	}

	public ArrayList<Bebida> getBebidas() {
		return this.bebidas;
	}
	
	public void addBebida(Bebida bebida) {
		this.bebidas.add(bebida);
	}
	
	public void removeBebida(Bebida bebida) {
		this.bebidas.remove(bebida);
	}

	public boolean isFinalizada() {
		return this.finalizada;
	}

	public void setFinalizada(boolean finalizada) {
		this.finalizada = finalizada;
	}
	
	public String toString() {		
		return String.valueOf(this.getNumero()) + ", " + String.valueOf(this.getConta()) + " - " + String.valueOf(this.isFinalizada());
	}
}
