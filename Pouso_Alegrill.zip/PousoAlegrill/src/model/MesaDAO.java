package model;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

public class MesaDAO extends ConexaoDAO{
	public ArrayList<Mesa> downloadMesa() throws SQLException{
		ArrayList<Mesa> mesa = new ArrayList<Mesa>();
		
		String sql;
		sql = "SELECT *FROM mesa";
		ps = connection.prepareStatement(sql);
		resultSet = ps.executeQuery();
		
		while(resultSet.next()){
			int id = resultSet.getInt("idMesa");
			int numero = resultSet.getInt("numero");
			float conta = resultSet.getFloat("conta");

			//mesa.add(new Mesa(id, numero, conta));
		}
		return mesa;
	}
	
	public void insertMesa(Mesa mesa) throws SQLException{
		String sql = "INSERT INTO Mesa (numero, conta) VALUES (?,?)";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, mesa.getNumero());
		ps.setFloat(2, mesa.getConta());
		ps.executeUpdate();
	}
	
	public void editMesa(Mesa mesa, int id) throws SQLException{
		String sql = "UPDATE mesa SET numero=?, conta=? WHERE idMesa=?";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, mesa.getNumero());
		ps.setFloat(2, mesa.getConta());
		ps.setInt(3, id);
		ps.executeUpdate();
	}	
	
	public void excluirMesa(Mesa mesa) throws SQLException{
		String sql = "DELETE FROM mesa WHERE idMesa=?";
		ps = connection.prepareStatement(sql);
		ps.setInt(1, mesa.getId());
		ps.executeUpdate();
	}
}
