package model;

public class Usuario {
	private int id;
	private String nome;
	private String email;
	private String senha;
	private int funcao; //1 - admin, 2 - atendimento, 3 - cozinha, 4 - bar
}
