package model;

public class UsuarioDAO {

}
