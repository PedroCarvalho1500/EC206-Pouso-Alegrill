package view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerAtendimento;
import controller.InputListenerEditarBebida;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;

public class Atendimento extends JFrame {

	private static final long serialVersionUID = 8373305023122725636L;
	private InputListenerAtendimento listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList listBebidas;
	private JButton btnFecharMesa;
	private JButton btnNovaMesa;
	private JButton btnAdicionar;
	private JButton btnLogout;
	private JList listMesas;
	private JList listComidas;
	private JTextArea textAreaItem;

	public Atendimento() {
		setTitle("ATENDIMENTO");
		initialize();
		setActionCommand();
		listener = new InputListenerAtendimento(this);
		listenerInitialize();
	}
	
	private void initialize() {		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnLogout());
			panel.add(getListBebidas());
			panel.add(getBtnFecharMesa());
			panel.add(getBtnFecharMesa());
			panel.add(getBtnNovaMesa());
			panel.add(getBtnAdicionar());
			panel.add(getListMesas());
			panel.add(getListComidas());
			panel.add(getTextAreaItem());			
		}
		return panel;
	}
	
	private JButton getBtnNovaMesa() {
		btnNovaMesa = new JButton("Nova Mesa");
		btnNovaMesa.setBounds(10, 201, 162, 24);
		return btnNovaMesa;
	}	
		
		private JTextArea getTextAreaItem() {
			textAreaItem = new JTextArea();
			textAreaItem.setBounds(10, 11, 162, 86);
		return textAreaItem;
	}

		private JList getListComidas() {
			listComidas = new JList();
			listComidas.setBounds(182, 11, 116, 179);
		return listComidas;
	}

		private JList getListMesas() {
			listMesas = new JList();
			listMesas.setBounds(10, 104, 162, 86);
			
		return listMesas;
	}

		private JButton getBtnAdicionar() {
			btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(182, 201, 116, 51);
		return btnAdicionar;
	}

		private JButton getBtnFecharMesa() {
			btnFecharMesa = new JButton("Fechar Mesa");
			btnFecharMesa.setBounds(10, 228, 162, 24);
		return btnFecharMesa;
	}

		private JList getListBebidas() {
			listBebidas = new JList();
			listBebidas.setBounds(308, 11, 116, 179);
		return listBebidas;
	}

		private JButton getBtnLogout() {
			if (btnLogout == null) {
				btnLogout = new JButton("LOGOUT");
				btnLogout.setBounds(308, 201, 116, 51);
			}
			return btnLogout;
		}
		
		private void setActionCommand() {
			getBtnLogout().setActionCommand("LOGOUT");
			getBtnAdicionar().setActionCommand("ADICIONAR");
			getBtnFecharMesa().setActionCommand("FECHAR");
			getBtnNovaMesa().setActionCommand("NOVA");
		}
}
