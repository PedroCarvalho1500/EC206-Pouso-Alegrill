package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerBar;
import model.Bebida;
import model.Mesa;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

public class Bar extends JFrame {

	private static final long serialVersionUID = -4375829440802350922L;
	private InputListenerBar listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList<String> list;
	private JButton btnLogout;
	private JButton btnPronto;
	private JButton btnIndisponivel;

	public Bar() {
		setTitle("BAR");
		initialize();
		setActionCommand();
		listener = new InputListenerBar(this);
		listenerInitialize();
	}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);		
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnLogout());
			panel.add(getList());
			panel.add(getBtnPronto());
			panel.add(getBtnIndisponivel());
		}
		return panel;

	}
	
	private JButton getBtnLogout() {
		if (btnLogout == null) {
			btnLogout = new JButton("LOGOUT");
			btnLogout.setBounds(280, 214, 144, 36);
		}
		return btnLogout;
	}
	
	private JButton getBtnPronto() {
		if (btnPronto == null) {
			btnPronto = new JButton("Pronto");
			btnPronto.setBounds(280, 11, 144, 48);
		}
		return btnPronto;
	}
	
	private JButton getBtnIndisponivel() {
		if (btnIndisponivel == null) {
			btnIndisponivel = new JButton("Indisponivel");
			btnIndisponivel.setBounds(280, 70, 144, 48);
		}
		return btnIndisponivel;
	}
	
	private JList getList() {
		if (list == null) {
			list = new JList();
			list.setVisibleRowCount(4);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list.setBounds(10, 11, 260, 239);
		}
		return list;
	}
	
	public String getSelectedItem() {
		String item = list.getModel().getElementAt(list.getSelectedIndex());
	}
	
	public void setList(DefaultListModel<String> listModel) {
		list.setModel(listModel);
	}
	
	private void setActionCommand() {
		getBtnLogout().setActionCommand("LOGOUT");
	}
	
	public DefaultListModel<String> getBar() {
		String stringBar = new String();
		DefaultListModel<String> listModel = new DefaultListModel<>();
		try {
			ArrayList<Bebida> fila = new ArrayList<>();
			ArrayList<Bebida> bebidas;
			/*
			mesaDAO.conectar();
			ArrayList<Mesa> mesas = mesaDAO.downloadMesas();
			mesaDAO.desconectar();
			*/
			for(Mesa mesa : mesas) {
				for(Bebida bebida : mesa.getBebidas()) {
					if (bebida.getServida() == false) {
						fila.add(bebida);
					}
				}
			}
			for(Bebida bebida : fila) {
				stringBar.concat(String.valueOf(bebida.getNumeroMesa()));
				stringBar.concat(" - ");
				stringBar.concat(bebida.getNome());
				stringBar.concat(";");
				listModel.addElement(stringBar);
				stringBar = null;
			}
		} catch (SQLException e) {
			String message = "Erro ao conectar ao banco de dados";
			JOptionPane.showMessageDialog(this, message, "ERRO BD", JOptionPane.ERROR_MESSAGE);
			System.out.println(e.getMessage());
		}
		return listModel;
	}
}
