package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerBar;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class Bar extends JFrame {

	private static final long serialVersionUID = -4375829440802350922L;
	private InputListenerBar listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList list;
	private JButton btnLogout;
	private JButton btnPronto;
	private JButton btnIndisponivel;

	public Bar() {
		setTitle("BAR");
		initialize();
		setActionCommand();
		listener = new InputListenerBar(this);
		listenerInitialize();
	}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);		
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnLogout());
			
			list = new JList();
			list.setBounds(10, 11, 260, 239);
			panel.add(list);
			
			btnPronto = new JButton("Pronto");
			btnPronto.setBounds(280, 11, 144, 48);
			panel.add(btnPronto);
			
			btnIndisponivel = new JButton("Indisponivel");
			btnIndisponivel.setBounds(280, 70, 144, 48);
			panel.add(btnIndisponivel);
		}
		return panel;

	}
	
	private JButton getBtnLogout() {
		if (btnLogout == null) {
			btnLogout = new JButton("LOGOUT");
			btnLogout.setBounds(280, 214, 144, 36);
		}
		return btnLogout;
	}
	
	private void setActionCommand() {
		getBtnLogout().setActionCommand("LOGOUT");
	}
}
