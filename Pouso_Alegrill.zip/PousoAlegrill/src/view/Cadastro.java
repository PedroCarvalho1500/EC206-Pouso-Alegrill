package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import controller.InputListenerCadastro;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

public class Cadastro extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8078668418163319487L;
	private InputListenerCadastro listener;
	private JPanel contentPane;
	private JTextField textNome;
	private JTextField textEmail;
	private JPasswordField textSenha;
	private JPasswordField textConfSenha;
	private JButton btnVoltar;
	private JButton btnCadastro;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cadastro frame = new Cadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cadastro() {
		setTitle("CADASTRO");
		setActionCommand();
		listener = new InputListenerCadastro(this);
		listenerInitialize();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textNome = new JTextField();
		textNome.setBounds(126, 25, 200, 24);
		contentPane.add(textNome);
		textNome.setColumns(10);
		
		textEmail = new JTextField();
		textEmail.setBounds(126, 57, 200, 24);
		contentPane.add(textEmail);
		textEmail.setColumns(10);
		
		textSenha = new JPasswordField();
		textSenha.setBounds(126, 88, 200, 24);
		contentPane.add(textSenha);
		textSenha.setColumns(10);
		
		textConfSenha = new JPasswordField();
		textConfSenha.setBounds(126, 119, 200, 24);
		contentPane.add(textConfSenha);
		textConfSenha.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(29, 30, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(29, 60, 46, 14);
		contentPane.add(lblEmail);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setBounds(29, 91, 46, 14);
		contentPane.add(lblSenha);
		
		JLabel lblConfSenha = new JLabel("Confirma Senha:");
		lblConfSenha.setBounds(29, 122, 86, 14);
		contentPane.add(lblConfSenha);
		
		JButton btnCadastro = new JButton("CADASTRAR");
		btnCadastro.setBounds(126, 154, 200, 36);
		contentPane.add(btnCadastro);
		
		JButton btnVoltar = new JButton("VOLTAR");
		btnVoltar.setBounds(126, 201, 200, 36);
		contentPane.add(btnVoltar);
	}
	
	private void listenerInitialize() {		
		btnVoltar.addActionListener(listener);
		btnCadastro.addActionListener(listener);		
	}
	
	private void setActionCommand() {
		btnVoltar.setActionCommand("VOLTAR");
		btnCadastro.setActionCommand("CADASTRAR");
	}
	
	public String getNome() {
		return textNome.getText();
	}
	public String getEmail() {
		return textEmail.getText();
	}
	public String getSenha() {
		return String.copyValueOf(textSenha.getPassword());
	}
	public String getConfirmaSenha() {
		return String.copyValueOf(textConfSenha.getPassword());
	}
}
