package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class Cozinha extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cozinha frame = new Cozinha();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cozinha() {
		setTitle("COZINHA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList list = new JList();
		list.setBounds(10, 11, 260, 239);
		contentPane.add(list);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBounds(280, 214, 144, 36);
		contentPane.add(btnLogout);
		
		JButton btnPronto = new JButton("Pronto");
		btnPronto.setBounds(280, 11, 144, 48);
		contentPane.add(btnPronto);
		
		JButton btnIndisponivel = new JButton("Indisponivel");
		btnIndisponivel.setBounds(280, 70, 144, 48);
		contentPane.add(btnIndisponivel);
	}
}
