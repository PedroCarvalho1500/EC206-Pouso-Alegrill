package view;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import controller.InputListenerCozinha;

import javax.swing.JList;
import javax.swing.JButton;

public class Cozinha extends JFrame {

	private static final long serialVersionUID = -3337704614943774559L;
	private InputListenerCozinha listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList list;
	private JButton btnLogout;
	private JButton btnPronto;
	private JButton btnIndisponivel;

	public Cozinha() {
		setTitle("COZINHA");
		initialize();
		setActionCommand();
		listener = new InputListenerCozinha(this);
		listenerInitialize();
	}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);		
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnLogout());
			
			list = new JList();
			list.setBounds(10, 11, 260, 239);
			panel.add(list);
			
			btnPronto = new JButton("Pronto");
			btnPronto.setBounds(280, 11, 144, 48);
			panel.add(btnPronto);
			
			btnIndisponivel = new JButton("Indisponivel");
			btnIndisponivel.setBounds(280, 70, 144, 48);
			panel.add(btnIndisponivel);
		}
		return panel;

	}
	
	private JButton getBtnLogout() {
		if (btnLogout == null) {
			btnLogout = new JButton("LOGOUT");
			btnLogout.setBounds(280, 214, 144, 36);
		}
		return btnLogout;
	}
	
	private void setActionCommand() {
		getBtnLogout().setActionCommand("LOGOUT");
	}
}
