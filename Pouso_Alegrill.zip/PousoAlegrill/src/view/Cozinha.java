package view;

import java.awt.BorderLayout;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;

import controller.InputListenerCozinha;
import model.Comida;
import model.Mesa;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;

public class Cozinha extends JFrame {

	private static final long serialVersionUID = -3337704614943774559L;
	private InputListenerCozinha listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList list;
	private JButton btnLogout;
	private JButton btnPronto;
	private JButton btnIndisponivel;

	public Cozinha() {
		setTitle("COZINHA");
		initialize();
		setActionCommand();
		listener = new InputListenerCozinha(this);
		listenerInitialize();
	}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);		
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnLogout());
			panel.add(getBtnPronto());
			panel.add(getBtnIndisponivel());
			panel.add(getList());
		}
		return panel;
	}
	
	private JList getList() {
		if (list == null) {
			list = new JList();
			list.setVisibleRowCount(4);
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			list.setBounds(10, 11, 260, 239);
		}
		return list;
	}
	
	public void setList(DefaultListModel<String> listModel) {
		list.setModel(listModel);
	}
	
	private JButton getBtnLogout() {
		if (btnLogout == null) {
			btnLogout = new JButton("LOGOUT");
			btnLogout.setBounds(280, 214, 144, 36);
		}
		return btnLogout;
	}
	
	private JButton getBtnPronto() {
		if (btnPronto == null) {
			btnPronto = new JButton("Pronto");
			btnPronto.setBounds(280, 11, 144, 48);
		}
		return btnPronto;
	}
	
	private JButton getBtnIndisponivel() {
		if (btnIndisponivel == null) {
			btnIndisponivel = new JButton("Indisponivel");
			btnIndisponivel.setBounds(280, 70, 144, 48);
		}
		return btnIndisponivel;
	}
	
	private void setActionCommand() {
		getBtnLogout().setActionCommand("LOGOUT");
	}
	
	public DefaultListModel<String> getCozinha() {
		String stringCozinha = new String();
		DefaultListModel<String> listModel = new DefaultListModel<>();
		try {
			ArrayList<Comida> fila = new ArrayList<>();
			ArrayList<Comida> comidas;
			/*
			mesaDAO.conectar();
			ArrayList<Mesa> mesas = mesaDAO.downloadMesas();
			mesaDAO.desconectar();
			*/
			for(Mesa mesa : mesas) {
				for(Comida comida : mesa.getComidas()) {
					if (comida.getServida() == false) {
						fila.add(comida);
					}
				}
			}
			for(Comida comida : fila) {
				stringCozinha.concat(String.valueOf(comida.getNumeroMesa()));
				stringCozinha.concat(" - ");
				stringCozinha.concat(comida.getNome());
				stringCozinha.concat(";");
				listModel.addElement(stringCozinha);
				stringCozinha = null;
			}
		} catch (SQLException e) {
			String message = "Erro ao conectar ao banco de dados";
			JOptionPane.showMessageDialog(this, message, "ERRO BD", JOptionPane.ERROR_MESSAGE);
			System.out.println(e.getMessage());
		}
		return listModel;
	}
}
