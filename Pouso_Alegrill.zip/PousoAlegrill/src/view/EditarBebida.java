package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarBebida extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8373305023122725636L;
	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldDescricao;
	private JTextField textFieldPreco;
	private JTextField textFieldQuantidade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarBebida frame = new EditarBebida();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarBebida() {
		setTitle("EDITAR BEBIDA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList list = new JList();
		list.setBounds(10, 11, 260, 179);
		contentPane.add(list);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(280, 12, 144, 14);
		contentPane.add(lblNome);
		
		textFieldNome = new JTextField();
		textFieldNome.setBounds(280, 26, 144, 20);
		contentPane.add(textFieldNome);
		textFieldNome.setColumns(10);
		
		JLabel lblDescricao = new JLabel("Descricao:");
		lblDescricao.setBounds(280, 46, 144, 14);
		contentPane.add(lblDescricao);
		
		textFieldDescricao = new JTextField();
		textFieldDescricao.setBounds(280, 60, 144, 20);
		contentPane.add(textFieldDescricao);
		textFieldDescricao.setColumns(10);
		
		JLabel lblCategoria = new JLabel("Categoria:");
		lblCategoria.setBounds(280, 80, 144, 14);
		contentPane.add(lblCategoria);
		
		JComboBox comboBoxCategoria = new JComboBox();
		comboBoxCategoria.setModel(new DefaultComboBoxModel(new String[] {"Alcoolica", "Nao alcoolica"}));
		comboBoxCategoria.setBounds(280, 94, 144, 20);
		contentPane.add(comboBoxCategoria);
		
		JLabel lblDisponivel = new JLabel("Disponivel:");
		lblDisponivel.setBounds(280, 114, 144, 14);
		contentPane.add(lblDisponivel);
		
		JComboBox comboBoxDisponivel = new JComboBox();
		comboBoxDisponivel.setModel(new DefaultComboBoxModel(new String[] {"Disponivel", "Indisponivel"}));
		comboBoxDisponivel.setBounds(280, 128, 144, 20);
		contentPane.add(comboBoxDisponivel);
		
		JLabel lblPreco = new JLabel("Preco:");
		lblPreco.setBounds(280, 148, 144, 14);
		contentPane.add(lblPreco);
		
		textFieldPreco = new JTextField();
		textFieldPreco.setColumns(10);
		textFieldPreco.setBounds(280, 162, 144, 20);
		contentPane.add(textFieldPreco);
		
		JLabel lblQuantidade = new JLabel("Quantidade:");
		lblQuantidade.setBounds(280, 182, 144, 14);
		contentPane.add(lblQuantidade);
		
		textFieldQuantidade = new JTextField();
		textFieldQuantidade.setColumns(10);
		textFieldQuantidade.setBounds(280, 196, 144, 20);
		contentPane.add(textFieldQuantidade);
		
		JLabel lblUnidade = new JLabel("Unidade:");
		lblUnidade.setBounds(280, 216, 144, 14);
		contentPane.add(lblUnidade);
		
		JComboBox comboBoxUnidade = new JComboBox();
		comboBoxUnidade.setModel(new DefaultComboBoxModel(new String[] {"Litro", "mL"}));
		comboBoxUnidade.setBounds(280, 230, 144, 20);
		contentPane.add(comboBoxUnidade);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(10, 228, 116, 24);
		contentPane.add(btnVoltar);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(10, 201, 116, 24);
		contentPane.add(btnSalvar);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(158, 201, 116, 24);
		contentPane.add(btnAdicionar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(158, 228, 116, 24);
		contentPane.add(btnExcluir);
	}
}
