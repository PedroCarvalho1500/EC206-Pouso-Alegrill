package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerEditarComida;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarComida extends JFrame {
	
	private static final long serialVersionUID = -8236302011996775772L;
	private InputListenerEditarComida listener;
	private JPanel contentPane;
	private JPanel panel;
	private JTextField textFieldNome;
	private JTextField textFieldDescricao;
	private JTextField textFieldPreco;
	private JTextField textFieldQuantidade;
	private JList list;
	private JLabel lblNome;
	private JLabel lblDescricao;
	private JLabel lblCategoria;
	private JComboBox comboBoxCategoria;
	private JLabel lblDisponivel;
	private JComboBox comboBoxDisponivel;
	private JLabel lblPreco;
	private JLabel lblQuantidade;
	private JLabel lblUnidade;
	private JComboBox comboBoxUnidade;
	private JButton btnSalvar;
	private JButton btnAdicionar;
	private JButton btnExcluir;
	private JButton btnVoltar;

	public EditarComida() {
		setTitle("EDITAR COMIDA");
		initialize();
		setActionCommand();
		listener = new InputListenerEditarComida(this);
		listenerInitialize();
	}
	
	private void initialize() {		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnVoltar().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnVoltar());
			
			list = new JList();
			list.setBounds(10, 11, 260, 179);
			panel.add(list);
			
			lblNome = new JLabel("Nome:");
			lblNome.setBounds(280, 12, 144, 14);
			panel.add(lblNome);
			
			textFieldNome = new JTextField();
			textFieldNome.setBounds(280, 26, 144, 20);
			panel.add(textFieldNome);
			textFieldNome.setColumns(10);
			
			lblDescricao = new JLabel("Descricao:");
			lblDescricao.setBounds(280, 46, 144, 14);
			panel.add(lblDescricao);
			
			textFieldDescricao = new JTextField();
			textFieldDescricao.setBounds(280, 60, 144, 20);
			panel.add(textFieldDescricao);
			textFieldDescricao.setColumns(10);
			
			lblCategoria = new JLabel("Categoria:");
			lblCategoria.setBounds(280, 80, 144, 14);
			panel.add(lblCategoria);
			
			comboBoxCategoria = new JComboBox();
			comboBoxCategoria.setModel(new DefaultComboBoxModel(new String[] {"Petisco", "Prato", "Sobremesa"}));
			comboBoxCategoria.setBounds(280, 94, 144, 20);
			panel.add(comboBoxCategoria);
			
			lblDisponivel = new JLabel("Disponivel:");
			lblDisponivel.setBounds(280, 114, 144, 14);
			panel.add(lblDisponivel);
			
			comboBoxDisponivel = new JComboBox();
			comboBoxDisponivel.setModel(new DefaultComboBoxModel(new String[] {"Disponivel", "Indisponivel"}));
			comboBoxDisponivel.setBounds(280, 128, 144, 20);
			panel.add(comboBoxDisponivel);
			
			lblPreco = new JLabel("Preco:");
			lblPreco.setBounds(280, 148, 144, 14);
			panel.add(lblPreco);
			
			textFieldPreco = new JTextField();
			textFieldPreco.setColumns(10);
			textFieldPreco.setBounds(280, 162, 144, 20);
			panel.add(textFieldPreco);
			
			lblQuantidade = new JLabel("Quantidade:");
			lblQuantidade.setBounds(280, 182, 144, 14);
			panel.add(lblQuantidade);
			
			textFieldQuantidade = new JTextField();
			textFieldQuantidade.setColumns(10);
			textFieldQuantidade.setBounds(280, 196, 144, 20);
			panel.add(textFieldQuantidade);
			
			lblUnidade = new JLabel("Unidade:");
			lblUnidade.setBounds(280, 216, 144, 14);
			panel.add(lblUnidade);
			
			comboBoxUnidade = new JComboBox();
			comboBoxUnidade.setModel(new DefaultComboBoxModel(new String[] {"Litro", "mL"}));
			comboBoxUnidade.setBounds(280, 230, 144, 20);
			panel.add(comboBoxUnidade);
			
			btnSalvar = new JButton("Salvar");
			btnSalvar.setBounds(10, 201, 116, 24);
			panel.add(btnSalvar);
			
			btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(158, 201, 116, 24);
			panel.add(btnAdicionar);
			
			btnExcluir = new JButton("Excluir");
			btnExcluir.setBounds(158, 228, 116, 24);
			panel.add(btnExcluir);
			
		}
		return panel;
	}		
		
	private JButton getBtnVoltar() {
		if(btnVoltar == null) {
			btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(10, 228, 116, 24);
		}
		return btnVoltar;
	}
	
	private void setActionCommand() {
		getBtnVoltar().setActionCommand("VOLTAR");
	}
}
