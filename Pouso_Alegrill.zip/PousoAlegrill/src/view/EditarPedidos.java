package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarPedidos extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8373305023122725636L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarPedidos frame = new EditarPedidos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarPedidos() {
		setTitle("EDITAR PEDIDOS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList listMesas = new JList();
		listMesas.setBounds(10, 11, 132, 179);
		contentPane.add(listMesas);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(10, 201, 116, 51);
		contentPane.add(btnVoltar);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(152, 201, 116, 51);
		contentPane.add(btnSalvar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(308, 201, 116, 51);
		contentPane.add(btnExcluir);
		
		JList listPedidos = new JList();
		listPedidos.setBounds(152, 11, 272, 179);
		contentPane.add(listPedidos);
	}
}
