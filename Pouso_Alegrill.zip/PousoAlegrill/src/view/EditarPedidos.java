package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerEditarPedidos;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarPedidos extends JFrame {

	private static final long serialVersionUID = 8373305023122725636L;
	private InputListenerEditarPedidos listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList listMesas;
	private JButton btnVoltar;
	private JButton btnSalvar;
	private JButton btnExcluir;
	private JList listPedidos;

	public EditarPedidos() {
		setTitle("EDITAR PEDIDOS");
		initialize();
		setActionCommand();
		listener = new InputListenerEditarPedidos(this);
		listenerInitialize();
	}
	
	public void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnVoltar().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnVoltar());
			
			listMesas = new JList();
			listMesas.setBounds(10, 11, 132, 179);
			panel.add(listMesas);
			
			btnSalvar = new JButton("Salvar");
			btnSalvar.setBounds(152, 201, 116, 51);
			panel.add(btnSalvar);
			
			btnExcluir = new JButton("Excluir");
			btnExcluir.setBounds(308, 201, 116, 51);
			panel.add(btnExcluir);
			
			listPedidos = new JList();
			listPedidos.setBounds(152, 11, 272, 179);
			panel.add(listPedidos);
			
		}
		return panel;
	}
	
	private JButton getBtnVoltar() {
		if (btnVoltar == null) {
			btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(10, 201, 116, 51);
		}
		return btnVoltar;
	}
	
	private void setActionCommand() {
		getBtnVoltar().setActionCommand("VOLTAR");
	}
}
