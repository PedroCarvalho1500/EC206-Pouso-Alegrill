package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarUsuario extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldEmail;
	private JTextField textFieldSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditarUsuario frame = new EditarUsuario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditarUsuario() {
		setTitle("EDITAR USUARIO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList list = new JList();
		list.setBounds(10, 11, 260, 179);
		contentPane.add(list);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(280, 12, 144, 14);
		contentPane.add(lblNome);
		
		textFieldNome = new JTextField();
		textFieldNome.setBounds(280, 26, 144, 20);
		contentPane.add(textFieldNome);
		textFieldNome.setColumns(10);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(280, 46, 144, 14);
		contentPane.add(lblEmail);
		
		textFieldEmail = new JTextField();
		textFieldEmail.setBounds(280, 60, 144, 20);
		contentPane.add(textFieldEmail);
		textFieldEmail.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setBounds(280, 80, 144, 14);
		contentPane.add(lblSenha);
		
		textFieldSenha = new JTextField();
		textFieldSenha.setColumns(10);
		textFieldSenha.setBounds(280, 94, 144, 20);
		contentPane.add(textFieldSenha);
		
		JLabel lblFuncao = new JLabel("Funcao:");
		lblFuncao.setBounds(280, 114, 144, 14);
		contentPane.add(lblFuncao);
		
		JComboBox comboBoxCategoria = new JComboBox();
		comboBoxCategoria.setModel(new DefaultComboBoxModel(new String[] {"Sem funcao", "Atendimento", "Cozinha", "Bar", "Administrador"}));
		comboBoxCategoria.setBounds(280, 128, 144, 20);
		contentPane.add(comboBoxCategoria);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(10, 226, 116, 24);
		contentPane.add(btnVoltar);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(10, 201, 116, 24);
		contentPane.add(btnSalvar);
		
		JButton btnAdicionar = new JButton("Adicionar");
		btnAdicionar.setBounds(154, 201, 116, 24);
		contentPane.add(btnAdicionar);
		
		JButton btnExcluir = new JButton("Excluir");
		btnExcluir.setBounds(154, 226, 116, 24);
		contentPane.add(btnExcluir);
	}
}
