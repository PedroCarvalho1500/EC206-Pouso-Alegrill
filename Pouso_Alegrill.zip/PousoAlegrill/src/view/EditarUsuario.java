package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerEditarUsuario;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;

public class EditarUsuario extends JFrame {
	
	private static final long serialVersionUID = 427889571756261812L;
	private InputListenerEditarUsuario listener;
	private JPanel contentPane;
	private JPanel panel;
	private JTextField textFieldNome;
	private JTextField textFieldEmail;
	private JTextField textFieldSenha;
	private JButton btnAdicionar;
	private JButton btnExcluir;
	private JButton btnSalvar;
	private JButton btnVoltar;
	private JComboBox comboBoxCategoria;
	private JLabel lblFuncao;
	private JLabel lblSenha;
	private JLabel lblEmail;
	private JLabel lblNome;
	private JList list;

	public EditarUsuario() {
		setTitle("EDITAR USUARIO");
		initialize();
		setActionCommand();
		listener = new InputListenerEditarUsuario(this);
		listenerInitialize();
	}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnVoltar().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnVoltar());
			
			list = new JList();
			list.setBounds(10, 11, 260, 179);
			panel.add(list);
			
			lblNome = new JLabel("Nome:");
			lblNome.setBounds(280, 12, 144, 14);
			panel.add(lblNome);
			
			textFieldNome = new JTextField();
			textFieldNome.setBounds(280, 26, 144, 20);
			panel.add(textFieldNome);
			textFieldNome.setColumns(10);
			
			lblEmail = new JLabel("Email:");
			lblEmail.setBounds(280, 46, 144, 14);
			panel.add(lblEmail);
			
			textFieldEmail = new JTextField();
			textFieldEmail.setBounds(280, 60, 144, 20);
			panel.add(textFieldEmail);
			textFieldEmail.setColumns(10);
			
			lblSenha = new JLabel("Senha:");
			lblSenha.setBounds(280, 80, 144, 14);
			panel.add(lblSenha);
			
			textFieldSenha = new JTextField();
			textFieldSenha.setColumns(10);
			textFieldSenha.setBounds(280, 94, 144, 20);
			panel.add(textFieldSenha);
			
			lblFuncao = new JLabel("Funcao:");
			lblFuncao.setBounds(280, 114, 144, 14);
			panel.add(lblFuncao);
			
			comboBoxCategoria = new JComboBox();
			comboBoxCategoria.setModel(new DefaultComboBoxModel(new String[] {"Sem funcao", "Atendimento", "Cozinha", "Bar", "Administrador"}));
			comboBoxCategoria.setBounds(280, 128, 144, 20);
			panel.add(comboBoxCategoria);
			
			btnSalvar = new JButton("Salvar");
			btnSalvar.setBounds(10, 201, 116, 24);
			panel.add(btnSalvar);
			
			btnAdicionar = new JButton("Adicionar");
			btnAdicionar.setBounds(154, 201, 116, 24);
			panel.add(btnAdicionar);
			
			btnExcluir = new JButton("Excluir");
			btnExcluir.setBounds(154, 226, 116, 24);
			panel.add(btnExcluir);
			
		}
		return panel;
	}
	
	private JButton getBtnVoltar() {
		if(btnVoltar == null) {
			btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(10, 226, 116, 24);
		}
		return btnVoltar;
	}
	
	private void setActionCommand() {
		getBtnVoltar().setActionCommand("VOLTAR");
	}
}
