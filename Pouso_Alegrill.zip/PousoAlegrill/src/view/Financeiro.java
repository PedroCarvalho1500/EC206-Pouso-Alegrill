package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.InputListenerEditarBebida;
import controller.InputListenerFinanceiro;

import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;

public class Financeiro extends JFrame {

	private static final long serialVersionUID = 8373305023122725636L;
	private InputListenerFinanceiro listener;
	private JPanel contentPane;
	private JPanel panel;
	private JList listComidas;
	private JList listMesas;
	private JButton btnFinalizarMesa;
	private JButton btnImprimirConta;
	private JButton btnRemover;
	private JButton btnVoltar;
	private JList listBebidas;
	private JTextArea textAreaItem;

	public Financeiro() {
		setTitle("FINANCEIRO");
		initialize();
		setActionCommand();
		listener = new InputListenerFinanceiro(this);
		listenerInitialize();
	}
	
	private void initialize() {		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnVoltar().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getBtnVoltar());
			
			listBebidas = new JList();
			listBebidas.setBounds(308, 11, 116, 179);
			panel.add(listBebidas);
			
			btnRemover = new JButton("Remover");
			btnRemover.setBounds(10, 201, 162, 24);
			panel.add(btnRemover);
			
			btnImprimirConta = new JButton("Imprimir Conta");
			btnImprimirConta.setBounds(182, 201, 116, 51);
			panel.add(btnImprimirConta);
			
			btnFinalizarMesa = new JButton("Finalizar Mesa");
			btnFinalizarMesa.setBounds(308, 201, 116, 51);
			panel.add(btnFinalizarMesa);
			
			listMesas = new JList();
			listMesas.setBounds(10, 104, 162, 86);
			panel.add(listMesas);
			
			listComidas = new JList();
			listComidas.setBounds(182, 11, 116, 179);
			panel.add(listComidas);
			
			textAreaItem = new JTextArea();
			textAreaItem.setBounds(10, 11, 162, 86);
			panel.add(textAreaItem);
		}
		return panel;
	}

	private JButton getBtnVoltar() {
		if(btnVoltar == null) {
			btnVoltar = new JButton("Voltar");
			btnVoltar.setBounds(10, 228, 162, 24);
		}
		return btnVoltar;
	}
	
	private void setActionCommand() {
		getBtnVoltar().setActionCommand("VOLTAR");
	}
}
