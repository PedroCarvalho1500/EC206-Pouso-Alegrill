package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;

public class Financeiro extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8373305023122725636L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Financeiro frame = new Financeiro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Financeiro() {
		setTitle("FINANCEIRO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JList listBebidas = new JList();
		listBebidas.setBounds(308, 11, 116, 179);
		contentPane.add(listBebidas);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.setBounds(10, 228, 162, 24);
		contentPane.add(btnVoltar);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.setBounds(10, 201, 162, 24);
		contentPane.add(btnRemover);
		
		JButton btnImprimirConta = new JButton("Imprimir Conta");
		btnImprimirConta.setBounds(182, 201, 116, 51);
		contentPane.add(btnImprimirConta);
		
		JButton btnFinalizarMesa = new JButton("Finalizar Mesa");
		btnFinalizarMesa.setBounds(308, 201, 116, 51);
		contentPane.add(btnFinalizarMesa);
		
		JList listMesas = new JList();
		listMesas.setBounds(10, 104, 162, 86);
		contentPane.add(listMesas);
		
		JList listComidas = new JList();
		listComidas.setBounds(182, 11, 116, 179);
		contentPane.add(listComidas);
		
		JTextArea textAreaItem = new JTextArea();
		textAreaItem.setBounds(10, 11, 162, 86);
		contentPane.add(textAreaItem);
	}
}
