package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MenuAdmin extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1125530819704100604L;
	private JPanel contentPane;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuAdmin frame = new MenuAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public MenuAdmin() {
		setTitle("MENU ADMINISTRADOR");
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnMesas = new JButton("Mesas");
		btnMesas.setBounds(10, 226, 80, 24);
		contentPane.add(btnMesas);
		
		JButton btnCozinha = new JButton("Cozinha");
		btnCozinha.setBounds(100, 226, 80, 24);
		contentPane.add(btnCozinha);
		
		JButton btnBar = new JButton("Bar");
		btnBar.setBounds(190, 226, 80, 24);
		contentPane.add(btnBar);
		
		JList list = new JList();
		list.setBounds(10, 11, 260, 179);
		contentPane.add(list);
		
		JLabel lblExibir = new JLabel("Exibir:");
		lblExibir.setBounds(10, 201, 46, 14);
		contentPane.add(lblExibir);
		
		JLabel lblEditar = new JLabel("Editar:");
		lblEditar.setBounds(280, 12, 46, 14);
		contentPane.add(lblEditar);
		
		JButton btnPedidos = new JButton("Pedidos");
		btnPedidos.setBounds(280, 37, 144, 24);
		contentPane.add(btnPedidos);
		
		JButton btnComidas = new JButton("Comidas");
		btnComidas.setBounds(280, 72, 144, 24);
		contentPane.add(btnComidas);
		
		JButton btnBebidas = new JButton("Bebidas");
		btnBebidas.setBounds(280, 107, 144, 24);
		contentPane.add(btnBebidas);
		
		JButton btnUsuarios = new JButton("Usuarios");
		btnUsuarios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnUsuarios.setBounds(280, 142, 144, 24);
		contentPane.add(btnUsuarios);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBounds(280, 214, 144, 36);
		contentPane.add(btnLogout);
		
		JButton btnFinanceiro = new JButton("Financeiro");
		btnFinanceiro.setBounds(280, 177, 144, 24);
		contentPane.add(btnFinanceiro);
	}
}
